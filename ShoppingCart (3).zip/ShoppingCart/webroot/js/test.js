
<h1>Shopping Cart
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script>
 $(document).ready(function(){
	$("button").click(function(){
		$(".test").hide();
});
});
</script>

<body>
<h2 class="test">This is a heading</h2>
<p class="test">This is a paragraph. </p>
<p > This is another paragraph. </p>

<button> Click me </button>

</h1>
</body>