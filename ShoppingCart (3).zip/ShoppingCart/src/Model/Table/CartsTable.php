<?php
// src/Model/Table/ProdctTable.php

namespace App\Model\Table;

use Cake\ORM\Table;

class CartsTable extends Table
{
// The $query argument is a query builder instance.
// The $options array will contain the 'tags' option we passed
// to find('tagged') in our controller action.
public function findById($id)
{
    return $this->find(
            'all',
			array(
            'conditions'=>array(product.id=>$id))
        });
}


}