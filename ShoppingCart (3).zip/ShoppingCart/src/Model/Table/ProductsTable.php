<?php
// src/Model/Table/ProdctTable.php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\ORM\Query;

class ProductsTable extends Table
{
public function initialize(array $config)
{
$this->addBehavior('Timestamp');
}

public function findById(Query $query,array $options)
{ 
     /*    $id = $options['id'];
return  $query ->where(['products.id' =>1]); */
	
		return 1;
	
        
}
}