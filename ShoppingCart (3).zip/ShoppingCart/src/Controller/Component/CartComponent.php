<?php
namespace App\Controller\Component;

use Cake\Controller\Component;
use Cake\ORM\Table;
use Cake\ORM\Query;
use Cake\ORM\TableRegistry;
class CartComponent extends Component {

//////////////////////////////////////////////////

   // public $components = array('Session');

//////////////////////////////////////////////////

    public $controller;

//////////////////////////////////////////////////

 public $uses = 'Products';

//////////////////////////////////////////////////


//////////////////////////////////////////////////

    public $maxQuantity = 99;

//////////////////////////////////////////////////

    public function addToCart($productId,$quantity = 0) {
 
 /* if(!is_numeric($quantity)) {
            $quantity = 1;
        }

        $quantity = abs($quantity);

        if($quantity > $this->maxQuantity) {
            $quantity = $this->maxQuantity;
        }

        if($quantity == 0) {
            $this->remove($id);
            return;
        }
		$query = TableRegistry::get('Products');
		$product = $query
                            ->find()
                            ->where(['id' => $productId])
                            ->first();
							
	    $data['product_id'] = $product->id;
        $data['name'] = $product->name;
        $data['price'] = $product->price;
        $data['quantity'] = $quantity++; */
            $allProducts = $this->readProduct();
        if (null!=$allProducts) {
            if (array_key_exists($productId, $allProducts)) {
                $allProducts[$productId]++;
            } else {
                $allProducts[$productId] = 1;// $product;
            }
        } else {
            $allProducts[$productId] =  1;//$product;
        }
         
        $this->saveProduct($allProducts);
    }

      

   


    /*
     * save data to session
     */
    public function saveProduct($data) {
        $session = $this->request->session();
        return $session->write('cart',$data);
    }

    /*
     * read cart data from session
     */
    public function readProduct() {
		$session = $this->request->session();
        $cart = $session->read('cart');
		
       return $cart ;

    }
//////////////////////////////////////////////////

    public function remove($id) {
        if($this->Session->check('Shop.OrderItem.' . $id)) {
            $product = $this->Session->read('Shop.OrderItem.' . $id);
            $this->Session->delete('Shop.OrderItem.' . $id);

            ClassRegistry::init('Cart')->deleteAll(
                array(
                    'Cart.sessionid' => $this->Session->id(),
                    'Cart.product_id' => $id,
                ),
                false
            );

            $this->cart();
            return $product;
        }
        return false;
    }

//////////////////////////////////////////////////
       /*
     * get total count of products
     */
    public function getCount() {
        $allProducts = $this->readProduct();
         
        if (count($allProducts)<1) {
            return 0;
        }
         
        $count = 0;
        foreach ($allProducts as $product) {
            $count=$count+$product;
        }
        
        return $count;
    }
	
	  public function cart() {
        $session = $this->request->session();
        $cart = $session->read('cart');
        $quantity = 0;
       

        if (count($cart['cart']) > 0) {
            foreach ($cart['cart'] as $item) {
                $quantity += $item['quantity'];
              
            }
		}
	  }
   

//////////////////////////////////////////////////

    public function clear() {
       // ClassRegistry::init('Cart')->deleteAll(array('Cart.sessionid' => $this->Session->id()), false);
	   $session = $this->request->session();
        $cart = $session->delete('cart');
       // return  $cart;
    }

	
//////////////////////////////////////////////////

}
