<?php

namespace App\Controller;
use Cake\Core\Configure;
use Cake\App\Controller\Component;
use Cake\ORM\TableRegistry;
class CartsController extends AppController {

 public $uses = array('Product','Cart');
    public function initialize()
    {
        parent::initialize();
        $this->loadComponent('Cart');
      //  $this->loadComponent('Comments', Configure::read('Comments'));
    }

    public function add() {
        if ($this->request->is('post')) {

            $id = $this->request->data['product_id'];
	 
//               $this->Cart->add($this->request->data['Cart']['product_id']);
         //  die($id);
		 
          $product = $this->Cart->addToCart($id);
		  
        }
		
		//echo $this->Cart->getCount();
        if(!empty($product)) {
            $this->Session->setFlash($product['Product']['name'] . ' was added to your shopping cart.', 'flash_success');
        } else {
           // $this->Session->setFlash('Unable to add this product to your shopping cart.');
		   $this->Flash->success('This was empty product');
        }
        $this->redirect($this->referer());
    }

  
    public function view() {
        $carts = $this->Cart->readProduct();
		//print_r(array_values($carts));
		
		// try to get count value of array
		
		$products = $carts;

	$query = TableRegistry::get('Products');
	    $products = array();
		if (null!=$carts) {
			foreach ($carts as $productId => $count) {
			//	DIE($productId);
				 $product = $query
                            ->find()
                            ->where(['id' => $productId])
                            ->first();
							
				$product['quantity'] = $count;
				$products[]=$product;
			}
		} 			$this->set(compact('products'));
    }

	 public function clear() {
       // ClassRegistry::init('Cart')->deleteAll(array('Cart.sessionid' => $this->Session->id()), false);
        $this->Cart->clear();
		$this->redirect($this->referer());
    }

    public function update() {
        if ($this->request->is('post')) {
            if (!empty($this->request->data)) {
                $cart = array();
                foreach ($this->request->data['count'] as $index=>$count) {
                    if ($count>0) {
                        $productId = $this->request->data['product_id'][$index];
                        $cart[$productId] = $count;
                    }
                }
                $this->Cart->saveProduct($cart);
            }
        }
        $this->redirect(array('action'=>'view'));
    }

}