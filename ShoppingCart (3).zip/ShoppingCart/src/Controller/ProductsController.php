<?php
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Network\Exception\NotFoundException;


class ProductsController extends AppController {

    public function index() {
        $this->set('products', $this->Products->find('all'));
    }

    public function view($id=null) {
        if (!$this->Products->exists($id)) {
            throw new NotFoundException(__('Invalid product'));
        }

        $product = $this->Products->get($id);
        $this->set(compact('product'));
    }

    public function edit($id = null)
    {
        $product = $this->Products->get($id);
        if ($this->request->is(['post', 'put'])) {
            $this->Producrs->patchEntity($product, $this->request->data);
            if ($this->Products->save($product)) {
                $this->Flash->success(__('Your article has been updated.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('Unable to update your article.'));
        }

        $this->set('article', $product);
    }
}
?>
